﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SenkougimeControl : MonoBehaviour
{
    public Text text;

    // Start is called before the first frame update
    void Start()
    {
        //int a = Random.Range(0, 2);

        //if (a == 0)
        //{
        //    text.text = "先攻";
        //}
        //else
        //{
        //    text.text = "後攻";
        //}

    }

    public void OnBttan()
    {
        int a = Random.Range(0, 2);

        if (a == 0)
        {
            text.text = "先攻";
        }
        else
        {
            text.text = "後攻";
        }

    }

}
