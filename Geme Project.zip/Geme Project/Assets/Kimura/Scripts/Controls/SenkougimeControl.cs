﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SenkougimeControl : MonoBehaviour
{
    public Text text;
    private float Step_time;
    // Start is called before the first frame update
    void Start()
    {
        int a = Random.Range(0, 2);

        if (a == 0)
        {
            text.text = "先攻";
        }
        else
        {
            text.text = "後攻";
        }

        Step_time = 0.0f;

    }

    void Update()
    {
        Step_time += Time.deltaTime;
        if (Step_time >= 3.0f)
        {
            SceneManager.LoadScene("MainGame");
        }
    }
}

